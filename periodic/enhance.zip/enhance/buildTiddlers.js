const {writeFile, mkdir, rm, cp} = require ('fs/promises')
const tiddlers = require ('./sources/Periodic-table-of-the-elements.json')
const table = require ('./sources/table.json')
const tableTid = {title: '$:/_/my/table', type: 'application/json', text: JSON.stringify(table)}
const tap = (fn) => (x) => ((fn (x)), x)
const map = (fn) => (xs) => xs .map (x => fn (x))

// spaces in some titles caused problems
const clean = (input) => ({tiddlers: Object .fromEntries (Object .entries (input .tiddlers) .map (
  ([k, t]) => [k .trim (), Object .fromEntries (Object .entries (t) .map (([k1, v]) => [k1 .trim (), String (v) === v ? v .trim () : v] ))]
))})

const normalizeNames = ((conversions = {
  'Wolfram' : 'Tungsten' // just the one?
}) => (input) => ({tiddlers: Object .fromEntries (Object .entries (input .tiddlers) .map (
  ([k, v]) => k in conversions 
    ? [conversions [k], Object .fromEntries (Object .entries ({...v, element: conversions [k], title: conversions [k]}).sort (([k1], [k2]) => k1 < k2 ? -1 : k1 > k2 ? 1 : 0))] 
    : [k, v]
))}))()

const fixFields = ((conversions = {
  type: 'elementtype'  // just the one?
}) => (o) => Object .fromEntries (Object .entries (o) .map (([k, v]) => [conversions [k] || k , v])))()

const fixElementType = ((conversions = {
  Moscovium: 'Transactinide',     //  \
  Nihonium: 'Transactinide',      //   +---- missing
  Tennessine: 'Transactinide',    //  /
  Hydrogen: 'Alkali Metal',       //  \
  Radium: 'Alkaline Earth Metal', //   | 
  Francium: 'Alkali Metal',       //   +---- Wikipedia disagrees with orginal data
  Astatine: 'Halogen',            //   |
  Radon: 'Noble Gas',             //  /
}) => (t) => t .title in conversions ? ((t .elementtype = conversions [t .title]), t) : t) ()

const wikipediaTitle = ((conversions = {
  Mercury: 'Mercury_(element)' // just the one?
}) => (title) => conversions [title] || title) ()

const tiddlerTitle = ((conversions = {
  Headers_Tiddler: '$:/_/my/headers'
}) => (o) => o .title in conversions ? ((o.title = conversions [o.title]), (o.elementtype = "ElementType"), (o.year = "YearDiscovered"), o): o) ()

const expandHeaders = (t) => t .title == '$:/_/my/headers'
  ? Object .fromEntries (Object .entries (t) .map (([k, v]) => [
      k,
      v .replace (/([a-z])([A-Z])/g, '$1 $2') .replace ('Numberof', 'Number of') .replace ('Number Of', 'Number of')
    ]))
  : t

const collect = (tiddlers) => Promise .all (Object .values (tiddlers .tiddlers) .map (
  t => fetch (`https://en.wikipedia.org/api/rest_v1/page/summary/${wikipediaTitle (t .title)}`)
      .then(r => r.json()) 
      .then (o => ({
        ...expandHeaders (tiddlerTitle (fixElementType (fixFields (t)))), 
        ...(o .extract 
          ? {text: '> ' + o.extract .split ('\n') .join ('\n> ') + `\n\n> ([[more information from Wikipedia|https://en.wikipedia.org/wiki/${wikipediaTitle (t .title)}]])`}
          : {}
        )
      }))
))

const addTiddler = (tid) => (tids) => tids .concat (tid)

const fileName = (t) => t.replace(/[:\/]/g, '_')

const format = ({text, title, ...rest}) => 
  [['title', title]] .concat (Object .entries (rest) .sort (([k1], [k2]) => k1 < k2 ? -1 : k1 > k2 ? +1 : 0))
    .map (([k, v]) => `${k}: ${v}`) .join ('\n') + (('atomicnumber' in rest) ? ('\n\n' + text) : '')

const write = (t) => writeFile ('./output/tiddlers/' + fileName (t.title) + '.tid', format (t))

const writePlugin = (ts) => (
  (writeFile(
    './output/plugin/Periodic-table-of-the-elements.json', 
    JSON .stringify ({tiddlers: {...Object .fromEntries(ts .map (t => [t .title, t])), tableTid}})
  )),
  cp ('./sources/Periodic-table-of-the-elements.json.meta', './output/plugin/Periodic-table-of-the-elements.json.meta')
)

const writeJson = (ts) => 
  writeFile ('./output/plugin/tiddlers.json', JSON .stringify (ts))

rm ('./output', {force: true, recursive: true})
  .then (() => mkdir ('./output/tiddlers', {recursive: true}))
  .then (() => mkdir ('./output/plugin', {recursive: true}))
  .then (() => clean (tiddlers))
  .then (normalizeNames)
  .then (collect)
  .then (tap (addTiddler (tableTid)))
  .then (tap (writePlugin))
  .then (tap (writeJson))
  .then (map (write))
  .then (xs => Promise .all (xs))
  .then (() => write (tableTid))
  .then (console .log  (`Writing ${Object .keys (tiddlers .tiddlers) .length + 1} tiddler files`))
  .catch (console .warn)